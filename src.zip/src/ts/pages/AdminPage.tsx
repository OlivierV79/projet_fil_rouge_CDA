import React from 'react';

const AdminPage: React.FC = () => {
    return (
        <div>
            <h1>Page Admin</h1>
        </div>
    );
};

export default AdminPage;
