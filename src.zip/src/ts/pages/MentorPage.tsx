import React from 'react';

const MentorPage: React.FC = () => {
    return (
        <div>
            <h1>Page Mentor</h1>
        </div>
    );
};

export default MentorPage;