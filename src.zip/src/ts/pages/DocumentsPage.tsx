import React from 'react';
import { useAuth } from '../contexts/AuthContext';
import UploadDocuments from "../components/documents/UploadDocuments.tsx";
import ShowDocuments from "../components/documents/ShowDocuments.tsx";

const DocumentsPage: React.FC = () => {
    const { username } = useAuth();
    return (
        <div>
            <h1>Documents {username} !</h1>
            <ShowDocuments />
            <UploadDocuments/>
        </div>
    );
};

export default DocumentsPage;