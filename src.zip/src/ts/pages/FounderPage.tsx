import React from 'react';

const FounderPage: React.FC = () => {
    return (
        <div>
            <h1>Page Porteur de projet</h1>
            <p>Si pas de mentor - liste des mentor</p>
            <p>Si mentor - prochain rdv  ou ????</p>
        </div>
    );
};

export default FounderPage;