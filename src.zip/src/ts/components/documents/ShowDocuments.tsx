import React, { useEffect, useState } from "react";
import { useAuth } from "../../contexts/AuthContext";

interface DocumentData {
    id: number;
    name: string;
    type: string;
    mimeType: string;
    ownerName: string;
}

const ShowDocuments: React.FC = () => {
    const { token } = useAuth();
    const [documents, setDocuments] = useState<DocumentData[]>([]);

    useEffect(() => {
        fetch("http://localhost:8080/api/documents/received", {
            headers: { Authorization: `Bearer ${token}` },
        })
            .then(res => res.json())
            .then(data => setDocuments(data))
            .catch(err => console.error(err));
    }, [token]);

    const handleDownload = (id: number) => {
        window.open(`http://localhost:8080/api/documents/download/${id}`, "_blank");
    };

    return (
        <div className="card">
            <h3>Mes documents reçus</h3>
            {documents.length === 0 ? (
                <p>Aucun document</p>
            ) : (
                <table>
                    <thead>
                    <tr>
                        <th>Nom</th>
                        <th>Type</th>
                        <th>Envoyé par</th>
                        <th></th>
                    </tr>
                    </thead>
                    <tbody>
                    {documents.map(doc => (
                        <tr key={doc.id}>
                            <td>{doc.name}</td>
                            <td>{doc.type}</td>
                            <td>{doc.ownerName}</td>
                            <td>
                                <button onClick={() => handleDownload(doc.id)}>Télécharger</button>
                            </td>
                        </tr>
                    ))}
                    </tbody>
                </table>
            )}
        </div>
    );
};

export default ShowDocuments;
