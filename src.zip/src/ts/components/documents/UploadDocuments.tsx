import React, { useState, useEffect } from "react";
import { useAuth } from "../../contexts/AuthContext";

interface Recipient {
    username: string;
    fullName: string;
}

const UploadDocuments: React.FC = () => {
    const { token, role } = useAuth();
    const [file, setFile] = useState<File | null>(null);
    const [type, setType] = useState("justificatif");
    const [recipient, setRecipient] = useState("");
    const [recipients, setRecipients] = useState<Recipient[]>([]);

    useEffect(() => {
        const fetchRecipients = async () => {
            let url = "";
            if (role === "FOUNDER") url = "/api/mentors/assigned";
            else if (role === "MENTOR") url = "/api/mentors/founders";

            if (url) {
                const res = await fetch(`http://localhost:8080${url}`, {
                    headers: { Authorization: `Bearer ${token}` },
                });
                const data = await res.json();
                setRecipients(data);
            }
        };

        fetchRecipients();
    }, [role, token]);

    const handleUpload = async (e: React.FormEvent) => {
        e.preventDefault();
        if (!file || !recipient) {
            alert("Sélectionner un fichier et un destinataire");
            return;
        }

        const formData = new FormData();
        formData.append("file", file);
        formData.append("type", type);

        const res = await fetch(`http://localhost:8080/api/documents/upload-to/${recipient}`, {
            method: "POST",
            headers: { Authorization: `Bearer ${token}` },
            body: formData,
        });

        if (res.ok) alert("Document envoyé !");
        else alert("Erreur lors de l'envoi");
    };

    return (
        <div className="card">
            <h3>Envoyer un document</h3>
            <form onSubmit={handleUpload}>
                <div>
                    <label>Type</label>
                    <select value={type} onChange={(e) => setType(e.target.value)}>
                        <option value="justificatif">Justificatif</option>
                        <option value="cv">CV</option>
                        <option value="autre">Autre</option>
                    </select>
                </div>

                <div>
                    <label>Destinataire</label>
                    <select value={recipient} onChange={(e) => setRecipient(e.target.value)}>
                        <option value="">-- Sélectionner --</option>
                        <option value="admin">Admin</option>
                        {recipients.map(r => (
                            <option key={r.username} value={r.username}>{r.fullName}</option>
                        ))}
                    </select>
                </div>

                <div>
                    <input type="file" onChange={(e) => e.target.files && setFile(e.target.files[0])} />
                </div>

                <button type="submit">Envoyer</button>
            </form>
        </div>
    );
};

export default UploadDocuments;
