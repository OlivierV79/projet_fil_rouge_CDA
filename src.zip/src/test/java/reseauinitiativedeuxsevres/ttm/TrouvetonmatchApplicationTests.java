package reseauinitiativedeuxsevres.ttm;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TrouvetonmatchApplicationTests {

    @Test
    void contextLoads() {
    }

}
