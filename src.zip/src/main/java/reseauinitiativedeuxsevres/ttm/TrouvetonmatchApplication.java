package reseauinitiativedeuxsevres.ttm;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TrouvetonmatchApplication {

    public static void main(String[] args) {
        SpringApplication.run(TrouvetonmatchApplication.class, args);
    }

}
