package reseauinitiativedeuxsevres.ttm.dto;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class SimpleMemberDTO {
    private Long username;
    private String fullName;
}
