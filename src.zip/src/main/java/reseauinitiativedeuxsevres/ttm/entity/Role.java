package reseauinitiativedeuxsevres.ttm.entity;

public enum Role {
    ADMIN, FOUNDER, MENTOR
}
